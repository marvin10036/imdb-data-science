# frozen_string_literal: true

FactoryBot.define do
  factory :title_genre do
    title
    genre
  end
end
