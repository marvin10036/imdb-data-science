# frozen_string_literal: true

FactoryBot.define do
  factory :title_writer do
    title
    person
  end
end
