# frozen_string_literal: true

FactoryBot.define do
  factory :title_director do
    title
    person
  end
end
