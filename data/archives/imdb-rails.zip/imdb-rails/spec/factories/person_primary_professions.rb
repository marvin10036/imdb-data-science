# frozen_string_literal: true

FactoryBot.define do
  factory :person_primary_profession do
    person
    profession
  end
end
