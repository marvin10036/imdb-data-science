# frozen_string_literal: true

FactoryBot.define do
  factory :person_known_for_title do
    person
    title
  end
end
