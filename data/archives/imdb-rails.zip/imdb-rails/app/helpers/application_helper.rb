# frozen_string_literal: true

# The application helper module
module ApplicationHelper
end
