# frozen_string_literal: true

# The base application controller
class ApplicationController < ActionController::Base
end
