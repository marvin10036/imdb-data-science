# frozen_string_literal: true

# Blueprint for profession models
class ProfessionBlueprint < Blueprinter::Base
  identifier :id

  fields :name
end
