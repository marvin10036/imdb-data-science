# frozen_string_literal: true

# Blueprint for language models
class LanguageBlueprint < Blueprinter::Base
  identifier :id

  fields :code, :name
end
