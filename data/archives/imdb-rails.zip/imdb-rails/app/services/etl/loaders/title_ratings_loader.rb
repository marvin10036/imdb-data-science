# frozen_string_literal: true

module Etl
  module Loaders
    # Processes the title.ratings.tsv.gz file
    class TitleRatingsLoader < BaseLoader
      include LoadHelper

      protected

      # Returns the name of the file that should be downloaded by the loader. For this loader the filename is
      # title.ratings.tsv.gz.
      #
      # @return [String] Returns title.episode.tsv.gz.
      def filename
        'title.ratings.tsv.gz'
      end

      # Process the data loaded from the title.ratings.tsv.gz file, and loads them to the database. This class
      # updates values for the {#Title} model.
      # Only processes ratings for movies (title_type = "movie")
      #
      # @param batch Array[Hash] The batch data.
      def process_data(batch)
        # Filter ratings only for movies that exist in the database
        movie_ratings_batch = filter_movie_ratings(batch)
        
        Rails.logger.info "Filtered #{movie_ratings_batch.size} movie ratings from #{batch.size} total ratings"
        
        return if movie_ratings_batch.empty?
        
        load_title_ratings(movie_ratings_batch)
      end

      private

      # Filter ratings to only include movies that exist in the database
      #
      # @param batch Array[Hash] The batch data.
      # @return Array[Hash] Filtered batch with only movie ratings.
      def filter_movie_ratings(batch)
        # Get all unique IDs from the batch
        tconst_ids = batch.map { |row| row[:tconst] }.uniq
        
        # Find which of these IDs correspond to movies in the database
        movie_ids = Title.where(unique_id: tconst_ids, title_type: 'movie').pluck(:unique_id).to_set
        
        # Filter batch to only include movie ratings
        batch.select { |row| movie_ids.include?(row[:tconst]) }
      end

      # Load the title ratings. It updates the ratings column for existing titles in the database.
      def load_title_ratings(batch)
        ActiveRecord::Base.connection.execute update_sql(batch)
      end

      # The update SQL needed to update ratings for titles
      #
      # @param batch Array[Hash] The batch data.
      # @return String The update SQL
      def update_sql(batch)
        values = batch.map { |row| "('#{row[:tconst]}', #{row[:averageRating]}, #{row[:numVotes]})" }.join(',')
        <<~SQL.squish
          UPDATE titles
          SET rating = title_ratings_insert.rating, votes = title_ratings_insert.votes, updated_at = NOW()
          FROM (VALUES #{values}) AS title_ratings_insert(unique_id, rating, votes)
          WHERE titles.unique_id = title_ratings_insert.unique_id;
        SQL
      end
    end
  end
end
