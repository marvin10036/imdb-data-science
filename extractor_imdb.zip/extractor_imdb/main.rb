# movie_collector.rb
require 'bundler/setup'
require 'themoviedb'
require 'httparty'
require 'csv'
require 'debug'
require 'dotenv/load'
require 'set'

class MovieCollector
  TMDB_API_KEY = ENV['TMDB_API_KEY']
  OMDB_API_KEY = ENV['OMDB_API_KEY']
  
  START_YEAR = 2000
  END_YEAR = 2025
  MIN_VOTES = 1000 # Mínimo de votos para considerar "significativo"
  MIN_VOTES_TOP_RATED = 500 # Mínimo de votos para top rated
  
  def initialize
    Tmdb::Api.key(TMDB_API_KEY)
    Tmdb::Api.language('pt-BR')
    @movies = {}
    @errors = []
  end
  
  def collect_all
    puts "🎬 Iniciando coleta de filmes (#{START_YEAR}-#{END_YEAR})..."

    collect_top_rated_movies  # NOVO
    collect_oscar_nominees
    collect_popular_movies
    
    puts "\n📊 Enriquecendo dados com IMDb/OMDb..."
    enrich_with_omdb
    
    puts "\n💾 Gerando CSV final..."
    export_to_csv
    
    print_summary
  end
  
  private
  
  def collect_oscar_nominees
    puts "\n🏆 Coletando filmes indicados ao Oscar..."
    
    (START_YEAR..END_YEAR).each do |year|
      begin
        # TMDb tem uma lista de filmes premiados/indicados
        # Vamos buscar filmes com keywords relacionadas ao Oscar
        results = Tmdb::Movie.search("oscar #{year}")
        
        results.results.each do |movie|
          next unless movie.release_date
          release_year = movie.release_date.split('-').first.to_i
          next unless release_year >= START_YEAR && release_year <= END_YEAR
          
          add_movie(movie.id, oscar_nominee: true)
        end
        
        sleep(0.25) # Rate limiting
      rescue => e
        log_error("Erro ao coletar Oscar #{year}: #{e.message}")
      end
    end
    
    puts "✅ Filmes do Oscar coletados: #{@movies.count { |_, m| m[:oscar_nominee] }}"
  end
  
  def collect_popular_movies
    puts "\n⭐ Coletando filmes populares..."
    
    (START_YEAR..END_YEAR).each do |year|
      begin
        # Descobrir filmes populares por ano
        discover = Tmdb::Movie.discover(
          primary_release_year: year,
          sort_by: 'vote_count.desc',
          'vote_count.gte': MIN_VOTES,
          page: 1
        )
        
        # Coletar as primeiras 3 páginas (60 filmes por ano)
        [1, 2, 3].each do |page|
          results = Tmdb::Movie.discover(
            primary_release_year: year,
            sort_by: 'vote_count.desc',
            'vote_count.gte': MIN_VOTES,
            page: page
          )
          
          results.results.each do |movie|
            add_movie(movie.id, oscar_nominee: false)
          end
          
          sleep(0.25)
        end
        
        puts "  #{year}: #{@movies.size} filmes únicos coletados"
      rescue => e
        log_error("Erro ao coletar populares #{year}: #{e.message}")
      end
    end
    
    puts "✅ Total de filmes únicos: #{@movies.size}"
  end

  # NOVO MÉTODO: Coletar filmes top rated
  def collect_top_rated_movies
    puts "\n🌟 Coletando filmes top rated (mais bem avaliados)..."
    
    (START_YEAR..END_YEAR).each do |year|
      begin
        # Buscar filmes com melhor avaliação por ano
        # Usando Discover com ordenação por vote_average
        [1, 2].each do |page|
          results = Tmdb::Movie.discover(
            primary_release_year: year,
            sort_by: 'vote_average.desc',
            'vote_count.gte': MIN_VOTES_TOP_RATED,
            'vote_average.gte': 7.0,  # Nota mínima de 7.0
            page: page
          )
          
          results.results.each do |movie|
            add_movie(movie.id, oscar_nominee: false, top_rated: true)
          end
          
          sleep(0.25)
        end
        
        puts "  #{year}: #{@movies.count { |_, m| m[:top_rated] }} filmes top rated"
      rescue => e
        log_error("Erro ao coletar top rated #{year}: #{e.message}")
      end
    end
    
    # Também coletar da lista geral de top rated do TMDb
    puts "\n📋 Coletando da lista geral Top Rated do TMDb..."
    begin
      # A lista top_rated do TMDb retorna os melhores filmes de todos os tempos
      # Vamos pegar várias páginas e filtrar por ano
      [1, 2, 3, 4, 5].each do |page|
        results = Tmdb::Movie.top_rated(page: page)
        
        results.results.each do |movie|
          next unless movie.release_date
          release_year = movie.release_date.split('-').first.to_i
          next unless release_year >= START_YEAR && release_year <= END_YEAR
          
          add_movie(movie.id, oscar_nominee: false, top_rated: true)
        end
        
        sleep(0.25)
      end
    rescue => e
      log_error("Erro ao coletar lista top rated geral: #{e.message}")
    end
    
    puts "✅ Total de filmes top rated: #{@movies.count { |_, m| m[:top_rated] }}"
  end

  def add_movie(tmdb_id, oscar_nominee:, top_rated: false)
    # Se o filme já existe, apenas atualizar os flags
    if @movies[tmdb_id]
      @movies[tmdb_id][:oscar_nominee] = true if oscar_nominee
      @movies[tmdb_id][:top_rated] = true if top_rated
      return
    end

    begin
      movie = Tmdb::Movie.detail(tmdb_id)
      credits = Tmdb::Movie.credits(tmdb_id)

      # Filtrar apenas longas-metragens (runtime >= 40 minutos)
      return if movie.runtime && movie.runtime < 40

      release_year = movie.release_date ? movie.release_date.split('-').first.to_i : nil
      return unless release_year && release_year >= START_YEAR && release_year <= END_YEAR

      @movies[tmdb_id] = {
        tmdb_id: tmdb_id,
        imdb_id: movie.imdb_id,
        title: movie.title,
        year: release_year,
        genres: movie.genres.map(&:name).join(', '),
        directors: extract_directors(credits),
        cast: extract_cast(credits),
        tmdb_rating: movie.vote_average,
        tmdb_votes: movie.vote_count,
        countries: movie.production_countries.map(&:name).join(', '),
        runtime: movie.runtime,
        budget: movie.budget > 0 ? movie.budget : nil,
        oscar_nominee: oscar_nominee,
        top_rated: top_rated,  # NOVO CAMPO
        # Campos a serem preenchidos pelo OMDb
        imdb_rating: nil,
        imdb_votes: nil,
        metascore: nil
      }
      
      sleep(0.25)
    rescue => e
      log_error("Erro ao adicionar filme TMDb ID #{tmdb_id}: #{e.message}")
    end
  end
  
  def extract_directors(credits)
    return '' unless credits && credits['crew']
    
    directors = credits['crew'].select { |c| c['job'] == 'Director' }
    directors.map { |d| d['name'] }.join(', ')
  end
  
  def extract_cast(credits)
    return '' unless credits && credits['cast']
    
    # Top 5 atores
    credits['cast'].first(5).map { |c| c['name'] }.join(', ')
  end
  
  def enrich_with_omdb
    return unless OMDB_API_KEY

    @movies.each_with_index do |(tmdb_id, movie), index|
      next unless movie[:imdb_id]

      begin
        omdb_data = fetch_omdb_data(movie[:imdb_id])
        
        if omdb_data
          movie[:imdb_rating] = omdb_data['imdbRating']
          movie[:imdb_votes] = omdb_data['imdbVotes']&.gsub(',', '')&.to_i
          movie[:metascore] = omdb_data['Metascore']
          
          # Complementar dados faltantes
          movie[:runtime] ||= parse_runtime(omdb_data['Runtime'])
          movie[:countries] = omdb_data['Country'] if movie[:countries].empty?
        end
        
        print "\r  Progresso: #{index + 1}/#{@movies.size}"
        sleep(0.25) # Rate limiting OMDb
      rescue => e
        log_error("Erro ao enriquecer IMDb ID #{movie[:imdb_id]}: #{e.message}")
      end
    end
    
    puts "\n✅ Enriquecimento concluído"
  end
  
  def fetch_omdb_data(imdb_id)
    response = HTTParty.get(
      "http://www.omdbapi.com/",
      query: {
        apikey: OMDB_API_KEY,
        i: imdb_id,
        plot: 'short'
      }
    )
    
    return nil unless response.code == 200
    data = response.parsed_response
    data['Response'] == 'True' ? data : nil
  end
  
  def parse_runtime(runtime_str)
    return nil unless runtime_str
    runtime_str.scan(/\d+/).first&.to_i
  end
  
  def export_to_csv
    filename = "movies_#{START_YEAR}_#{END_YEAR}_#{Time.now.strftime('%Y%m%d_%H%M%S')}.csv"
    
    CSV.open(filename, 'w', write_headers: true, headers: csv_headers) do |csv|
      @movies.values.sort_by { |m| [-m[:year], -m[:tmdb_votes]] }.each do |movie|
        csv << [
          movie[:title],
          movie[:year],
          movie[:genres],
          movie[:directors],
          movie[:cast],
          movie[:imdb_rating],
          movie[:imdb_votes],
          movie[:metascore],
          movie[:countries],
          movie[:runtime],
          movie[:budget],
          movie[:oscar_nominee] ? 'Sim' : 'Não',
          movie[:top_rated] ? 'Sim' : 'Não',  # NOVA COLUNA
          movie[:imdb_id],
          movie[:tmdb_id]
        ]
      end
    end
    
    puts "✅ CSV gerado: #{filename}"
    @csv_filename = filename
  end
  
  def csv_headers
    [
      'Título',
      'Ano',
      'Gêneros',
      'Diretores',
      'Elenco Principal',
      'Nota IMDb',
      'Votos IMDb',
      'Metascore',
      'País',
      'Duração (min)',
      'Orçamento (USD)',
      'Indicado ao Oscar',
      'Top Rated',  # NOVA COLUNA
      'IMDb ID',
      'TMDb ID'
    ]
  end
  
  def log_error(message)
    @errors << message
    puts "⚠️  #{message}"
  end
  
  def print_summary
    puts "\n" + "="*60
    puts "📈 RESUMO DA COLETA"
    puts "="*60
    puts "Total de filmes coletados: #{@movies.size}"
    puts "Filmes indicados ao Oscar: #{@movies.count { |_, m| m[:oscar_nominee] }}"
    puts "Filmes top rated: #{@movies.count { |_, m| m[:top_rated] }}"  # NOVA LINHA
    puts "Filmes com dados do IMDb: #{@movies.count { |_, m| m[:imdb_rating] }}"
    puts "Erros encontrados: #{@errors.size}"
    puts "Arquivo gerado: #{@csv_filename}"
    puts "="*60
    
    if @errors.any?
      puts "\n⚠️  Primeiros 10 erros:"
      @errors.first(10).each { |e| puts "  - #{e}" }
    end
  end
end

# Executar
if __FILE__ == $0
  collector = MovieCollector.new
  collector.collect_all
end